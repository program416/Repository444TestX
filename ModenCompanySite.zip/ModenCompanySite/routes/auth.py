from config import ADMIN_ID, ADMIN_PW
from flask import Blueprint, render_template, request, redirect, session

auth_bp = Blueprint("auth", __name__)

@auth_bp.route("/login", methods=["GET", "POST"])
def login():
    if request.method == "POST":
        user = request.form["username"]
        pw = request.form["password"]

        if user == ADMIN_ID and pw == ADMIN_PW:
            session["user"] = user
            return redirect("/")
        return "접근 거부"

    return render_template("login.html")

@auth_bp.route("/logout")
def logout():
    session.pop("user", None)
    return redirect("/login")
