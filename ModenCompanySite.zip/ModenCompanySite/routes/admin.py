from datetime import datetime

from flask import Blueprint, render_template, request, session, redirect

from models import load_posts, save_posts

admin_bp = Blueprint("admin", __name__)

@admin_bp.route("/admin")
def admin():
    if "user" not in session:
        return redirect("/login")
    return render_template("admin.html")

@admin_bp.route("/write", methods=["GET", "POST"])
def write():
    if "user" not in session:
        return redirect("/login")

    if request.method == "POST":
        title = request.form["title"]
        content = request.form["content"]

        posts = load_posts()
        posts.insert(0, {
            "title": title,
            "content": content,
            "date": datetime.now().strftime("%Y-%m-%d %H:%M")
        })

        save_posts(posts)
        return redirect("/")

    return render_template("write.html")
