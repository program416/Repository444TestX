from flask import Blueprint, render_template, session, redirect

from models import load_posts

main_bp = Blueprint("main", __name__)

@main_bp.route("/")
def home():
    if "user" not in session:
        return redirect("/login")

    posts = load_posts()
    return render_template("home.html", posts=posts)
