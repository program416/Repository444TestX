import os

from flask import Flask, request, abort

from routes.admin import admin_bp
from routes.auth import auth_bp
from routes.main import main_bp

def create_app():
    from flask import request

    app = Flask(__name__)
    app.secret_key = "modencompany_v3_secret"

    if not os.path.exists("data"):
        os.makedirs("data")

    if not os.path.exists("data/data.json"):
        with open("data/data.json", "w", encoding="utf-8") as f:
            f.write("[]")

    @app.before_request
    def log_request():
        app.logger.info(
            f"{request.remote_addr} {request.method} {request.path}"
        )

    @app.errorhandler(404)
    def not_found(e):
        app.logger.warning(f"404 발생: {request.path}")
        return "페이지 없음", 404

    @app.errorhandler(500)
    def server_error(e):
        app.logger.error(f"500 서버 오류: {str(e)}")
        return "서버 내부 오류", 500

    @app.before_request
    def allow_only_same_wifi():
        ip = request.remote_addr

        if not ip.startswith("192.168.200."):
            abort(403)

    app.register_blueprint(auth_bp)
    app.register_blueprint(main_bp)
    app.register_blueprint(admin_bp)

    return app
